## Interface: 90100
## Title: Shadow Crescent Roll Helper
## Notes: A simple addon to aid in rolling. Designed primarily for roleplaying events.
## Author: Danternas (Thomas Johansson) (C) All Rights Reserved.
## Version: 0.4 Alpha
## DefaultState: enabled
## SavedVariablesPerCharacter: SCrollHelperDB
## Contact: dev.danternas@gmail.com

## How to use:
Use /scroll or /scrollhelper to toggle the meny. 

Use the checkboxes to choose what rows to save for next login.

The addon will call a roll with Name, X-Y and the use Z as a modifier. The results will be given to you in the main chat window.